int * split(int factor, int dimension);
char *outputFormat(char str[256], char replace[128], char substr[128]);
int fileToOpen(int row, int col);

int factor;
char str[128];
char *substr;
char *fileName = NULL;
char *fileTemplate = NULL;
