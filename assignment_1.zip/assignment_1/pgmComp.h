int width2 = 0;
int height2 = 0;
int maxGray2 = 0;
unsigned char ** data2D2;
