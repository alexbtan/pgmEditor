//Compression factor
int factor;
