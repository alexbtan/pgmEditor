//These temporarily hold row and col values to check if they are the max
int tempCol;
int tempRow;
//These store the highest row and column of the tiles
int maxCol = 0;
int maxRow = 0;

//These hold the maximum width and height of the entire image
int maxWidth = 0;
int maxHeight = 0;
